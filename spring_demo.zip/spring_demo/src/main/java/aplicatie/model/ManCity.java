package aplicatie.model;

import lombok.Setter;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


public class ManCity implements ClubActions{
    @Setter
    private final List<Player> players = new ArrayList<>();

    public ManCity() {
        players.add(new Player("Kevin De Bruyne", "attacking midfilder", 80000000));
    }

    public List<Player> getPlayers(){
        return Collections.unmodifiableList(players);
    }

    @Override
    public void addPlayer(Player toAdd) {
        players.add(toAdd);
    }

    @Override
    public void removePlayer(Player toRemove) {
        players.remove(toRemove);
    }
}
