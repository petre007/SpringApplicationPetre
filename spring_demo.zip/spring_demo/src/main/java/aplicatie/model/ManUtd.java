package aplicatie.model;

import lombok.Getter;
import lombok.NonNull;
import lombok.Setter;


import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Getter
@Setter
public class ManUtd implements ClubActions{

    private final List<Player> players = new ArrayList<>();

    public ManUtd(){
        players.add(new Player("Edison Cavani", "striker", 1000000));
        players.add(new Player("Jadon Sancho", "right midfilder", 72000000));
        players.add(new Player("David de Gea", "goalkeper", 45000000));
    }


    public List<Player> getPlayers() {
        return Collections.unmodifiableList(players);
    }

    @Override
    public void addPlayer(@NonNull Player toAdd) {
        players.add(toAdd);
    }

    @Override
    public void removePlayer(Player toRemove) {
        for(Player player : players){
            if(player.getName().equals(toRemove.getName())){
                players.remove(toRemove);
            }
        }
    }
}
