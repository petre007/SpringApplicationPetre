package aplicatie.model;

public interface ClubActions {

    void addPlayer(Player toAdd);

    void removePlayer(Player toRemove);


}
