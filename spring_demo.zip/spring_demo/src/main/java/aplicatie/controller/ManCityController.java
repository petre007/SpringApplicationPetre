package aplicatie.controller;

import aplicatie.model.ManCity;
import aplicatie.model.Player;
import aplicatie.service.ManCityService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
@Slf4j
public class ManCityController {

    private ManCityService manCityService;

    @Autowired
    public ManCityController(ManCityService manCityService) {
        this.manCityService = manCityService;
    }

    @ModelAttribute
    public ManCity team(){
        return manCityService.getData();
    }

    @GetMapping("man_city")
    public String manCity(){
        return "man_city";
    }
    @GetMapping("add_man_city")
    public String addEditPlayer(Model model){
        Player player = new Player("", "",0);
        model.addAttribute("player", player);
        return "add_man_city";
    }


    @PostMapping("add_man_city")
    public String processPlayer(@ModelAttribute("player") Player player ){
        log.info("player from form = {}", player);
        manCityService.addPlayer(player);
        return "redirect:/"+"man_city";
    }


}
