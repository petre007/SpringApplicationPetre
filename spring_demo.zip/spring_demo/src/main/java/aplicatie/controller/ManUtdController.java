package aplicatie.controller;

import aplicatie.model.ManUtd;
import aplicatie.model.Player;
import aplicatie.service.ManUnitedService;
import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Slf4j
@Controller
public class ManUtdController {

   private final ManUnitedService manUnitedService;

   @Autowired
    public ManUtdController(ManUnitedService manUnitedService) {
        this.manUnitedService = manUnitedService;
    }

    @ModelAttribute
    public ManUtd team(){
        return manUnitedService.getData();
    }


    @GetMapping("man_utd")
    public String manUtd(){
        log.info("manUtd method called");
        return "man_utd";
    }

    @GetMapping("add_man_utd")
    public String addEditPlayer(Model model){
        Player player = new Player("", "",0);
        model.addAttribute("player", player);
        return "add_man_utd";
    }


    @PostMapping("add_man_utd")
    public String processPlayer(@ModelAttribute("player") Player player ){
        log.info("player from form = {}", player);
        manUnitedService.addPlayer(player);
        return "redirect:/"+"man_utd";
    }

}
