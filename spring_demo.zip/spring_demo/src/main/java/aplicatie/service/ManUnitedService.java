package aplicatie.service;

import aplicatie.model.ManUtd;
import aplicatie.model.Player;

public interface ManUnitedService {

    void addPlayer(Player toAdd);

    void removePlayer(Player toRemove);

    ManUtd getData();


}
