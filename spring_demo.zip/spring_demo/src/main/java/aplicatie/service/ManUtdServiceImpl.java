package aplicatie.service;

import aplicatie.model.ManUtd;
import aplicatie.model.Player;
import lombok.Getter;
import org.springframework.stereotype.Service;

@Service
public class ManUtdServiceImpl implements ManUnitedService {

    @Getter
    private final ManUtd data = new ManUtd();

    @Override
    public void addPlayer(Player toAdd) {
        data.addPlayer(toAdd);
    }

    @Override
    public void removePlayer(Player toRemove) {
        data.removePlayer(toRemove);
    }

}
