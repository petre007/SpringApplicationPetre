package aplicatie.service;

import aplicatie.model.ManCity;
import aplicatie.model.Player;

public interface ManCityService {

    void addPlayer(Player toAdd);

    void removePlayer(Player toRemove);

    ManCity getData();

}
