package aplicatie.service;

import aplicatie.model.ManCity;
import aplicatie.model.Player;
import lombok.Getter;
import org.springframework.stereotype.Service;

@Service
public class ManCityServiceImpl implements ManCityService{

    @Getter
    private final ManCity data = new ManCity();

    @Override
    public void addPlayer(Player toAdd) {
        data.addPlayer(toAdd);
    }

    @Override
    public void removePlayer(Player toRemove) {
        data.removePlayer(toRemove);
    }

}
